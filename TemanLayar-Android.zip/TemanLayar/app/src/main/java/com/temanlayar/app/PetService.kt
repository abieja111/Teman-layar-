package com.temanlayar.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Choreographer
import android.view.Gravity
import android.view.WindowManager
import kotlin.math.max
import kotlin.math.min

class PetService : Service() {
    companion object {
        const val ACTION_STOP = "com.temanlayar.app.STOP"
        const val ACTION_RESPAWN = "com.temanlayar.app.RESPAWN"
        const val ACTION_SIZE = "com.temanlayar.app.SIZE"
        const val ACTION_CHARS = "com.temanlayar.app.CHARS"
        const val EXTRA_SIZE = "size"
        const val PREFS = "teman"
        const val PREF_SIZE = "size"
        const val PREF_CHARS = "chars"
        private const val CHANNEL = "teman_layar"
        private const val NOTIF_ID = 1

        @Volatile
        var running = false

        /** Daftar id karakter yang dipilih, dipisah koma. Minimal satu. */
        fun readChars(prefs: android.content.SharedPreferences): List<String> {
            val raw = prefs.getString(PREF_CHARS, "haimiya") ?: "haimiya"
            val ids = raw.split(",").map { it.trim() }.filter { Sprites.has(it) }.distinct()
            return if (ids.isEmpty()) listOf("haimiya") else ids
        }
    }

    private lateinit var wm: WindowManager

    private val actors = ArrayList<Actor>()
    private var sizeKey = "m"
    private var density = 1f
    private var screenW = 1080f
    private var screenH = 2400f
    private var groundY = 2200f
    private var railY = 160f
    private var lastNs = 0L
    private var frameCount = 0
    private var ready = false

    /** Satu karakter di layar: logika gerak, view, dan jendela overlay miliknya sendiri. */
    private inner class Actor(val id: String) {
        val set: SpriteSet = Sprites.get(this@PetService, id)
        val pet = Pet(set)
        val view = PetView(this@PetService, pet)
        val lp: WindowManager.LayoutParams

        var winW = 1
        var winH = 1
        var gndW = 1
        var gndH = 1
        var airW = 1
        var airH = 1
        var padTop = 0f
        var padBottom = 0f

        init {
            pet.density = density
            val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
            lp = WindowManager.LayoutParams(
                1,
                1,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                flags,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            lp.x = 0
            lp.y = -10000 // disembunyikan sampai posisi pertama dihitung
            if (Build.VERSION.SDK_INT >= 28) {
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }

        fun start() {
            pushScreen()
            lp.width = winW
            lp.height = winH
            view.setLayoutInfo(winW, winH, padTop, padBottom)
            wm.addView(view, lp)
            pet.spawn(null)
        }

        fun destroy() {
            try {
                wm.removeView(view)
            } catch (e: Exception) {
                // jendela sudah hilang
            }
        }

        fun pushScreen() {
            pet.screenW = screenW
            pet.screenH = screenH
            pet.groundY = groundY
            pet.railY = railY
        }

        fun applySize(key: String) {
            val heightDp = when (key) {
                "s" -> 96f
                "l" -> 168f
                else -> 128f
            }
            // K sama untuk semua karakter. Perbedaan ukuran gambar diurus oleh set.px.
            pet.K = heightDp * density / 276f
            val u = pet.K * set.px

            // Di lantai jendela dibuat sekecil mungkin supaya sentuhan di sekitarnya tetap sampai ke aplikasi lain.
            // Saat dibawa, jatuh atau bergelantungan jendela dilebarkan agar ayunan tidak terpotong.
            var gHalf = 0f
            var gMaxH = 0f
            var aHalf = 0f
            var aMaxH = 0f
            var hangH = 0f
            for ((name, spr) in set.entries()) {
                val half = max(spr.ax, spr.w - spr.ax)
                aHalf = max(aHalf, half)
                aMaxH = max(aMaxH, spr.h.toFloat())
                if (name.startsWith("hang") || name.startsWith("swing")) {
                    hangH = max(hangH, spr.h.toFloat())
                } else {
                    gHalf = max(gHalf, half)
                    gMaxH = max(gMaxH, spr.h.toFloat())
                }
            }
            val pad = 8f * density
            padTop = 22f * pet.K + pad
            padBottom = pad
            val swing = kotlin.math.sin(1.05f * Pet.ROT_K)
            gndW = (2f * gHalf * u * 1.1f + 2f * pad).toInt()
            gndH = (gMaxH * u + padTop + padBottom).toInt()
            airW = (2f * (aHalf + hangH * swing) * u + 2f * pad).toInt()
            airH = (max(aMaxH, hangH) * u + padTop + padBottom).toInt()
            winW = gndW
            winH = gndH
        }

        fun applyWindow() {
            val ground = pet.mode == Pet.Mode.GROUND
            val w = if (ground) gndW else airW
            val h = if (ground) gndH else airH
            if (w != winW || h != winH) {
                winW = w
                winH = h
                view.setLayoutInfo(winW, winH, padTop, padBottom)
            }
            val nx = (pet.x - winW / 2f).toInt()
            val ny = (if (ground) pet.y - (winH - padBottom) else pet.y - padTop).toInt()
            if (nx != lp.x || ny != lp.y || winW != lp.width || winH != lp.height) {
                lp.x = nx
                lp.y = ny
                lp.width = winW
                lp.height = winH
                try {
                    wm.updateViewLayout(view, lp)
                } catch (e: Exception) {
                    // view belum/tidak lagi terpasang
                }
            }
        }
    }

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!ready) return
            val dt = if (lastNs == 0L) 0.016f else min(0.05f, (frameTimeNanos - lastNs) / 1_000_000_000f)
            lastNs = frameTimeNanos
            if (frameCount++ % 45 == 0) {
                readScreen()
                for (a in actors) a.pushScreen()
            }
            val now = SystemClock.uptimeMillis()
            for (a in actors) {
                a.pet.update(dt, now)
                a.applyWindow()
                a.view.invalidate()
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startFg()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        running = true
        density = resources.displayMetrics.density
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        sizeKey = prefs.getString(PREF_SIZE, "m") ?: "m"
        readScreen()
        syncActors()
        ready = true
        Choreographer.getInstance().postFrameCallback(frameCb)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_RESPAWN -> if (ready) for (a in actors) a.pet.despawn()
            ACTION_SIZE -> if (ready) {
                sizeKey = intent.getStringExtra(EXTRA_SIZE) ?: "m"
                for (a in actors) {
                    a.applySize(sizeKey)
                    a.view.setLayoutInfo(a.winW, a.winH, a.padTop, a.padBottom)
                }
            }
            ACTION_CHARS -> if (ready) syncActors()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        ready = false
        running = false
        Choreographer.getInstance().removeFrameCallback(frameCb)
        for (a in actors) a.destroy()
        actors.clear()
        super.onDestroy()
    }

    /** Samakan karakter di layar dengan pilihan di pengaturan. */
    private fun syncActors() {
        val want = readChars(getSharedPreferences(PREFS, MODE_PRIVATE))
        val it = actors.iterator()
        while (it.hasNext()) {
            val a = it.next()
            if (a.id !in want) {
                a.destroy()
                it.remove()
            }
        }
        for (id in want) {
            if (actors.none { a -> a.id == id }) {
                val a = Actor(id)
                a.applySize(sizeKey)
                a.start()
                actors.add(a)
            }
        }
    }

    // ---------- layar ----------

    @Suppress("DEPRECATION")
    private fun readScreen() {
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        val w = dm.widthPixels
        val h = dm.heightPixels
        screenW = w.toFloat()
        screenH = h.toFloat()
        val portrait = h >= w
        val statusBar = dimenPx("status_bar_height")
        val gesture = Settings.Secure.getInt(contentResolver, "navigation_mode", 0) == 2
        val navBar = if (!portrait) 0 else if (gesture) dimenPx("navigation_bar_gesture_height") else dimenPx("navigation_bar_height")
        groundY = h - navBar - 6f * density
        railY = statusBar + 30f * density
    }

    private fun dimenPx(name: String): Int {
        val id = resources.getIdentifier(name, "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else 0
    }

    // ---------- notifikasi ----------

    private fun createChannel() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(CHANNEL, "Teman Layar", NotificationManager.IMPORTANCE_LOW)
        ch.setShowBadge(false)
        nm.createNotificationChannel(ch)
    }

    private fun action(act: String, label: String, code: Int): Notification.Action {
        val pi = PendingIntent.getService(
            this,
            code,
            Intent(this, PetService::class.java).setAction(act),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat), label, pi).build()
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Teman Layar aktif")
            .setContentText("Karakter sedang berkeliaran di layar Anda")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(action(ACTION_RESPAWN, "Pop up lagi", 1))
            .addAction(action(ACTION_STOP, "Hentikan", 2))
            .build()
    }

    private fun startFg() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }
}
