package com.temanlayar.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Choreographer
import android.view.Gravity
import android.view.WindowManager
import kotlin.math.max
import kotlin.math.min

class PetService : Service() {
    companion object {
        const val ACTION_STOP = "com.temanlayar.app.STOP"
        const val ACTION_RESPAWN = "com.temanlayar.app.RESPAWN"
        const val ACTION_SIZE = "com.temanlayar.app.SIZE"
        const val EXTRA_SIZE = "size"
        const val PREFS = "teman"
        const val PREF_SIZE = "size"
        private const val CHANNEL = "teman_layar"
        private const val NOTIF_ID = 1

        @Volatile
        var running = false
    }

    private lateinit var wm: WindowManager
    private lateinit var pet: Pet
    private lateinit var view: PetView
    private lateinit var lp: WindowManager.LayoutParams

    private var density = 1f
    private var winW = 0
    private var winH = 0
    private var gndW = 0
    private var gndH = 0
    private var airW = 0
    private var airH = 0
    private var padTop = 0f
    private var padBottom = 0f
    private var lastNs = 0L
    private var frameCount = 0
    private var ready = false

    private val frameCb = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!ready) return
            val dt = if (lastNs == 0L) 0.016f else min(0.05f, (frameTimeNanos - lastNs) / 1_000_000_000f)
            lastNs = frameTimeNanos
            if (frameCount++ % 45 == 0) readScreen()
            pet.update(dt, SystemClock.uptimeMillis())
            applyWindow()
            view.invalidate()
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startFg()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        running = true
        Sprites.load(this)
        density = resources.displayMetrics.density
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        pet = Pet()
        pet.density = density
        readScreen()
        applySize(getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_SIZE, "m") ?: "m")

        view = PetView(this, pet)
        view.setLayoutInfo(winW, winH, padTop, padBottom)

        val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED
        lp = WindowManager.LayoutParams(
            winW,
            winH,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = 0
        lp.y = -10000 // disembunyikan sampai posisi pertama dihitung
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wm.addView(view, lp)

        pet.spawn(null)
        ready = true
        Choreographer.getInstance().postFrameCallback(frameCb)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_RESPAWN -> if (ready) pet.despawn()
            ACTION_SIZE -> if (ready) {
                applySize(intent.getStringExtra(EXTRA_SIZE) ?: "m")
                view.setLayoutInfo(winW, winH, padTop, padBottom)
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        ready = false
        running = false
        Choreographer.getInstance().removeFrameCallback(frameCb)
        if (this::view.isInitialized) {
            try {
                wm.removeView(view)
            } catch (e: Exception) {
                // jendela sudah hilang
            }
        }
        super.onDestroy()
    }

    // ---------- ukuran dan posisi ----------

    private fun applySize(key: String) {
        val heightDp = when (key) {
            "s" -> 96f
            "l" -> 168f
            else -> 128f
        }
        val idleH = Sprites.map["idle6"]?.h ?: 276
        pet.K = heightDp * density / idleH

        // Di lantai jendela dibuat sekecil mungkin supaya sentuhan di sekitarnya tetap sampai ke aplikasi lain.
        // Saat dibawa, jatuh atau bergelantungan jendela dilebarkan agar ayunan tidak terpotong.
        var gHalf = 0f
        var gMaxH = 0f
        var aHalf = 0f
        var aMaxH = 0f
        var hangH = 0f
        for ((name, spr) in Sprites.map) {
            val half = max(spr.ax, spr.w - spr.ax)
            aHalf = max(aHalf, half)
            aMaxH = max(aMaxH, spr.h.toFloat())
            if (name.startsWith("hang") || name.startsWith("swing")) {
                hangH = max(hangH, spr.h.toFloat())
            } else {
                gHalf = max(gHalf, half)
                gMaxH = max(gMaxH, spr.h.toFloat())
            }
        }
        val pad = 8f * density
        padTop = 22f * pet.K + pad
        padBottom = pad
        val swing = kotlin.math.sin(1.05f * Pet.ROT_K)
        gndW = (2f * gHalf * pet.K * 1.1f + 2f * pad).toInt()
        gndH = (gMaxH * pet.K + padTop + padBottom).toInt()
        airW = (2f * (aHalf + hangH * swing) * pet.K + 2f * pad).toInt()
        airH = (max(aMaxH, hangH) * pet.K + padTop + padBottom).toInt()
        winW = gndW
        winH = gndH
    }

    @Suppress("DEPRECATION")
    private fun readScreen() {
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        val w = dm.widthPixels
        val h = dm.heightPixels
        pet.screenW = w.toFloat()
        pet.screenH = h.toFloat()
        val portrait = h >= w
        val statusBar = dimenPx("status_bar_height")
        val gesture = Settings.Secure.getInt(contentResolver, "navigation_mode", 0) == 2
        val navBar = if (!portrait) 0 else if (gesture) dimenPx("navigation_bar_gesture_height") else dimenPx("navigation_bar_height")
        pet.groundY = h - navBar - 6f * density
        pet.railY = statusBar + 30f * density
    }

    private fun dimenPx(name: String): Int {
        val id = resources.getIdentifier(name, "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else 0
    }

    private fun applyWindow() {
        val ground = pet.mode == Pet.Mode.GROUND
        val w = if (ground) gndW else airW
        val h = if (ground) gndH else airH
        if (w != winW || h != winH) {
            winW = w
            winH = h
            view.setLayoutInfo(winW, winH, padTop, padBottom)
        }
        val nx = (pet.x - winW / 2f).toInt()
        val ny = (if (ground) pet.y - (winH - padBottom) else pet.y - padTop).toInt()
        if (nx != lp.x || ny != lp.y || winW != lp.width || winH != lp.height) {
            lp.x = nx
            lp.y = ny
            lp.width = winW
            lp.height = winH
            try {
                wm.updateViewLayout(view, lp)
            } catch (e: Exception) {
                // view belum/tidak lagi terpasang
            }
        }
    }

    // ---------- notifikasi ----------

    private fun createChannel() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(CHANNEL, "Teman Layar", NotificationManager.IMPORTANCE_LOW)
        ch.setShowBadge(false)
        nm.createNotificationChannel(ch)
    }

    private fun action(act: String, label: String, code: Int): Notification.Action {
        val pi = PendingIntent.getService(
            this,
            code,
            Intent(this, PetService::class.java).setAction(act),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat), label, pi).build()
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("Teman Layar aktif")
            .setContentText("Karakter sedang berkeliaran di layar Anda")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(action(ACTION_RESPAWN, "Pop up lagi", 1))
            .addAction(action(ACTION_STOP, "Hentikan", 2))
            .build()
    }

    private fun startFg() {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }
}
