package com.temanlayar.app

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.random.Random

/**
 * Perilaku karakter. Semua posisi dalam piksel layar.
 *
 * GROUND : berdiri/jalan/lari di lantai (titik pegangan = kaki)
 * DRAG   : sedang dibawa jari (titik pegangan = tangan)
 * AIR    : jatuh atau terlempar
 * HANG   : bergelantungan di batang
 */
class Pet(val set: SpriteSet) {
    enum class Mode { GONE, GROUND, DRAG, AIR, HANG }

    var mode = Mode.GONE
    var st = "stand"
    var x = 0f
    var y = 0f
    var vx = 0f
    var vy = 0f

    private var t = 0f
    private var dir = 1
    private var anim = 0f
    private var sc = 1f
    private var sqAmp = 0f
    private var landPower = 0.5f

    /** Offset lompat kecil saat menyapa (piksel, ke atas). */
    var hop = 0f
        private set

    // bandul untuk pose bergelantungan
    private var th = 0f
    private var w = 0f
    private var px = 0f
    private var pvxe = 0f
    private var axs = 0f

    var shim = 0
        private set
    private var shimT = 0f
    private var kickT = 0f
    private var oneHand: String? = null
    private var oneT = 0f
    private var lifeT = 0f

    private var seq: List<Pair<String, Float>> = emptyList()
    private var seqI = 0
    private var offx = 0f
    private var offy = 0f

    /** True saat sedang dibawa dan sudah cukup dekat dengan batang. */
    var nearRail = false
        private set
    var everHung = false
        private set

    // skala gambar untuk frame saat ini
    var drawSx = 1f
        private set
    var drawSy = 1f
        private set

    // lingkungan (diisi oleh service)
    var screenW = 1080f
    var screenH = 2400f
    var groundY = 2200f
    var railY = 160f
    var K = 1f
    var density = 3f

    // sentuhan
    private var ptrX = 0f
    private var ptrY = 0f
    private var ptrVx = 0f
    private var ptrVy = 0f
    private var ptrT = 0L
    private var pressing = false
    private var started = false
    private var pressX0 = 0f
    private var pressY0 = 0f
    private var pressT0 = 0L

    private fun rnd(a: Float, b: Float): Float = a + Random.nextFloat() * (b - a)
    private fun clamp(v: Float, a: Float, b: Float): Float = if (v < a) a else if (v > b) b else v
    private fun easeOutBack(p: Float): Float {
        val c1 = 1.70158f
        val c3 = c1 + 1f
        return 1f + c3 * (p - 1f).pow(3) + c1 * (p - 1f).pow(2)
    }

    private fun feetOff(): Float {
        val s = set.get("hang1") ?: return 200f * K
        return (s.h - s.ay) * K * set.px
    }

    private fun halfW(): Float = set.halfW * K + 8f * density
    private fun snap(): Float = 70f * density

    // ---------- muncul / hilang ----------

    fun spawn(atX: Float? = null) {
        mode = Mode.GROUND
        st = "pop"
        t = 0.5f
        anim = 0f
        val lo = halfW() + 20f * density
        val hi = max(lo + 1f, screenW - halfW() - 20f * density)
        x = atX ?: rnd(lo, hi)
        y = groundY
        vx = 0f; vy = 0f; th = 0f; w = 0f; sc = 0f; hop = 0f
        dir = if (Random.nextBoolean()) -1 else 1
    }

    fun despawn() {
        if (mode == Mode.GONE) return
        pressing = false
        started = false
        nearRail = false
        mode = Mode.GROUND
        st = "out"
        t = 0.18f
        y = groundY
        hop = 0f; th = 0f; w = 0f
        val lo = halfW()
        x = clamp(x, lo, max(lo, screenW - lo))
    }

    // ---------- di lantai ----------

    private fun next(newSt: String, newT: Float) {
        st = newSt
        t = newT
        anim = 0f
    }

    private fun startTurn(newDir: Int) {
        dir = newDir
        next("turn", 0.3f)
    }

    private fun flipMaybe() {
        dir = if (x < screenW * 0.22f) 1 else if (x > screenW * 0.78f) -1 else if (Random.nextBoolean()) -1 else 1
    }

    private fun startLook() {
        if (set.looks.isEmpty()) {
            next("stand", rnd(1f, 2f))
            return
        }
        seq = set.looks[Random.nextInt(set.looks.size)]
        seqI = 0
        t = seq[0].second
    }

    private fun pickNext() {
        val r = Random.nextFloat()
        if (st == "walk" || st == "run") {
            when {
                r < 0.55f -> next("stand", rnd(1.2f, 3.2f))
                r < 0.75f -> { next("look", 0f); startLook() }
                else -> { next("walk", rnd(2.5f, 6f)); flipMaybe() }
            }
            return
        }
        when {
            r < 0.52f -> { next("walk", rnd(3f, 8f)); flipMaybe() }
            r < 0.64f -> { next("run", rnd(1.3f, 2.8f)); flipMaybe() }
            r < 0.80f -> { next("look", 0f); startLook() }
            else -> next("stand", rnd(1.4f, 3.6f))
        }
    }

    private fun groundUpdate(dt: Float) {
        y = groundY
        hop = 0f
        th = 0f
        w = 0f
        t -= dt
        val minX = halfW()
        val maxX = max(minX, screenW - halfW())
        x = clamp(x, minX, maxX)
        when (st) {
            "pop" -> {
                sc = easeOutBack(clamp(1f - t / 0.5f, 0f, 1f))
                if (t <= 0f) { sc = 1f; next("stand", rnd(1.2f, 2.4f)) }
            }
            "out" -> {
                sc = clamp(t / 0.18f, 0f, 1f)
                if (t <= 0f) spawn(null)
            }
            "land" -> {
                val p = clamp(1f - t / 0.3f, 0f, 1f)
                sqAmp = sin(p * PI.toFloat()) * landPower
                if (t <= 0f) { sqAmp = 0f; next("stand", rnd(0.8f, 1.8f)) }
            }
            "greet" -> {
                val el = 1.8f - t
                hop = if (el < 0.95f) abs(sin(el * PI.toFloat() * 2.1f)) * 22f * K else 0f
                if (t <= 0f) next("stand", rnd(1f, 2f))
            }
            "stand" -> if (t <= 0f) pickNext()
            "walk", "run" -> {
                val speed = (if (st == "run") 1.15f else 0.42f) * 276f * K
                x += dir * speed * dt
                anim += dt
                if (x <= minX) { x = minX; startTurn(1) }
                else if (x >= maxX) { x = maxX; startTurn(-1) }
                else if (t <= 0f) pickNext()
            }
            "turn" -> if (t <= 0f) next("walk", rnd(2.5f, 6f))
            "look" -> if (t <= 0f) {
                seqI++
                if (seqI >= seq.size) next("stand", rnd(1.2f, 2.6f)) else t = seq[seqI].second
            }
        }
    }

    private fun groundPose(): String = when (st) {
        "walk" -> {
            val i = (anim * 7f).toInt() % 4
            "walk" + (if (dir < 0) i else 4 + i)
        }
        "run" -> {
            val j = (anim * 11f).toInt() % 4
            "run" + (if (dir < 0) j else 4 + j)
        }
        "turn" -> if (dir > 0) set.turnRight else set.turnLeft
        "look" -> if (seq.isEmpty()) set.stand else seq[min(seqI, seq.size - 1)].first
        "greet" -> set.greet
        else -> set.stand
    }

    // ---------- bandul (dibawa, jatuh, bergelantungan) ----------

    private fun pend(dt: Float) {
        val vxe = (x - px) / dt
        val ax = clamp((vxe - pvxe) / dt, -6000f, 6000f)
        pvxe = vxe
        px = x
        axs += (ax - axs) * (1f - exp(-dt * 20f))
        val len = 90f * K
        val alpha = -OM2 * sin(th) - DAMP * w + (axs / len) * cos(th)
        w += alpha * dt
        th += w * dt
        if (th > 1.05f) { th = 1.05f; w *= -0.3f }
        if (th < -1.05f) { th = -1.05f; w *= -0.3f }
    }

    private fun hangPose(): String {
        val a = abs(th)
        if (a > 0.42f) return if (th > 0f) "swingL0" else "swingR0"
        if (a > 0.14f) return if (th > 0f) "hang0" else "hang2"
        val one = oneHand
        if (mode == Mode.HANG && one != null) return one
        return "hang1"
    }

    fun poseName(): String = if (mode == Mode.GROUND) groundPose() else hangPose()

    /** Sudut ayunan (radian) di sekitar titik pegangan. */
    fun rotation(): Float = if (mode == Mode.GROUND) 0f else th * ROT_K

    private fun grabRail() {
        mode = Mode.HANG
        lifeT = rnd(11f, 19f)
        shim = 0
        shimT = rnd(1f, 2f)
        kickT = rnd(1.4f, 2.8f)
        oneHand = null
        oneT = rnd(3f, 5f)
        vx = 0f
        everHung = true
    }

    private fun hangUpdate(dt: Float) {
        y += (railY - y) * (1f - exp(-dt * 16f))
        lifeT -= dt
        shimT -= dt
        if (shimT <= 0f) {
            if (shim != 0) { shim = 0; shimT = rnd(2f, 4.5f) }
            else if (Random.nextFloat() < 0.5f) { shim = if (Random.nextBoolean()) -1 else 1; shimT = rnd(1.6f, 3f) }
            else shimT = rnd(2f, 4f)
        }
        val vt = shim * 120f * K
        vx += (vt - vx) * (1f - exp(-dt * 5f))
        x += vx * dt
        val minX = halfW() + 10f * density
        val maxX = max(minX, screenW - halfW() - 10f * density)
        if (x < minX) { x = minX; if (shim != 0) shim = 1; vx = 0f }
        if (x > maxX) { x = maxX; if (shim != 0) shim = -1; vx = 0f }
        kickT -= dt
        if (kickT <= 0f) {
            w += (if (Random.nextBoolean()) -1f else 1f) * rnd(0.9f, 1.9f)
            kickT = rnd(1.3f, 3.2f)
        }
        oneT -= dt
        if (oneT <= 0f) {
            if (oneHand != null) { oneHand = null; oneT = rnd(3f, 6f) }
            else if (Random.nextFloat() < 0.4f) {
                oneHand = if (Random.nextBoolean()) "hangL0" else "hangR0"
                oneT = rnd(2f, 3.5f)
            } else oneT = rnd(3f, 5f)
        }
        pend(dt)
        if (lifeT <= 0f) {
            mode = Mode.AIR
            vx = rnd(-60f, 60f) * density
            vy = 0f
        }
    }

    // ---------- jatuh ----------

    private fun airUpdate(dt: Float) {
        val g = 3400f * K
        vy = min(vy + g * dt, 4700f * K)
        x += vx * dt
        y += vy * dt
        vx *= exp(-0.8f * dt)
        val minX = halfW()
        val maxX = max(minX, screenW - halfW())
        if (x < minX) { x = minX; vx = abs(vx) * 0.5f }
        if (x > maxX) { x = maxX; vx = -abs(vx) * 0.5f }
        pend(dt)
        if (vy < 0f && y <= railY + 4f * density) {
            y = railY
            grabRail()
            return
        }
        val top = railY - 10f * density
        if (y < top) { y = top; vy = abs(vy) * 0.3f }
        if (y + feetOff() >= groundY) {
            landPower = clamp(vy / (2700f * K), 0.25f, 1f)
            mode = Mode.GROUND
            st = "land"
            t = 0.3f
            y = groundY
            sc = 1f
            th = 0f; w = 0f; vx = 0f; vy = 0f
        }
    }

    // ---------- sentuhan ----------

    fun pressDown(rawX: Float, rawY: Float, now: Long) {
        pressing = true
        started = false
        pressX0 = rawX
        pressY0 = rawY
        pressT0 = now
        ptrX = rawX
        ptrY = rawY
        ptrVx = 0f
        ptrVy = 0f
        ptrT = now
    }

    fun pressMove(rawX: Float, rawY: Float, now: Long) {
        if (!pressing) return
        val dt = max(0.008f, (now - ptrT) / 1000f)
        ptrVx = ptrVx * 0.6f + ((rawX - ptrX) / dt) * 0.4f
        ptrVy = ptrVy * 0.6f + ((rawY - ptrY) / dt) * 0.4f
        ptrX = rawX
        ptrY = rawY
        ptrT = now
        if (!started && hypot(rawX - pressX0, rawY - pressY0) > 6f * density) startDrag()
    }

    fun pressUp(now: Long) {
        if (!pressing) return
        pressing = false
        if (!started) tap() else release(now)
        started = false
    }

    private fun startDrag() {
        if (started) return
        started = true
        if (mode == Mode.GROUND) {
            y = groundY - feetOff()
            th = 0f; w = 0f; sc = 1f; sqAmp = 0f; hop = 0f
        }
        mode = Mode.DRAG
        px = x
        pvxe = 0f
        axs = 0f
        offx = x - ptrX
        offy = y - ptrY
    }

    private fun dragUpdate(dt: Float) {
        val tx = ptrX + offx
        val ty = ptrY + offy
        val r = 1f - exp(-dt * 26f)
        x += (tx - x) * r
        y += (ty - y) * r
        x = clamp(x, 8f * density, screenW - 8f * density)
        val topY = railY - 10f * density
        y = clamp(y, topY, max(topY, groundY - feetOff()))
        pend(dt)
        nearRail = y <= railY + snap()
    }

    private fun release(now: Long) {
        nearRail = false
        if (now - ptrT > 90) { ptrVx = 0f; ptrVy = 0f }
        if (y <= railY + snap()) {
            grabRail()
        } else {
            mode = Mode.AIR
            vx = clamp(ptrVx * 0.7f, -900f * density, 900f * density)
            vy = clamp(ptrVy * 0.7f, -1500f * density, 1400f * density)
        }
    }

    private fun tap() {
        if (mode == Mode.HANG) {
            w += (if (ptrX < x) -1f else 1f) * 2.6f
        } else if (mode == Mode.GROUND && st in TAPPABLE) {
            next("greet", 1.8f)
        }
    }

    // ---------- loop utama ----------

    fun update(dtIn: Float, now: Long) {
        if (pressing && !started && now - pressT0 > 180) startDrag()
        val dt = max(dtIn, 0.001f)
        when (mode) {
            Mode.GROUND -> groundUpdate(dt)
            Mode.DRAG -> dragUpdate(dt)
            Mode.AIR -> airUpdate(dt)
            Mode.HANG -> hangUpdate(dt)
            Mode.GONE -> {}
        }
        if (mode == Mode.GROUND) {
            var sx = 1f
            var sy = 1f
            if (st == "land") { sx = 1f + 0.09f * sqAmp; sy = 1f - 0.13f * sqAmp }
            drawSx = sx * sc
            drawSy = sy * sc
        } else {
            drawSx = 1f
            drawSy = 1f
        }
    }

    companion object {
        private const val OM2 = 15f
        private const val DAMP = 0.9f
        const val ROT_K = 0.5f
        private val TAPPABLE = listOf("stand", "walk", "run", "look", "turn")
    }
}
