package com.temanlayar.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import kotlin.math.max

/**
 * View kecil yang ikut berpindah bersama karakter. Jendela overlay dibuat seukuran karakter,
 * jadi sentuhan di luar area ini tetap sampai ke aplikasi di bawahnya.
 */
class PetView(context: Context, private val pet: Pet) : View(context) {
    private var winW = 0
    private var winH = 0
    private var padTop = 0f
    private var padBottom = 0f

    private val density = resources.displayMetrics.density
    private val spritePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val shapePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val railColor = Color.parseColor("#4C4D58")
    private val accentColor = Color.parseColor("#A3ACF2")
    private val rect = RectF()

    fun setLayoutInfo(w: Int, h: Int, top: Float, bottom: Float) {
        winW = w
        winH = h
        padTop = top
        padBottom = bottom
        invalidate()
    }

    private fun anchorX(): Float = winW / 2f

    private fun anchorY(): Float =
        if (pet.mode == Pet.Mode.GROUND) winH - padBottom - pet.hop else padTop

    override fun onDraw(canvas: Canvas) {
        if (pet.mode == Pet.Mode.GONE) return
        val s = Sprites.map[pet.poseName()] ?: return
        val axw = anchorX()
        val ayw = anchorY()
        val k = pet.K

        if (pet.mode == Pet.Mode.GROUND) {
            val f = pet.drawSx.coerceIn(0f, 1f)
            shapePaint.color = Color.argb((38 * f).toInt(), 10, 12, 24)
            val feetY = winH - padBottom
            rect.set(axw - 44f * k * f, feetY - 7f * k * f, axw + 44f * k * f, feetY + 7f * k * f)
            canvas.drawOval(rect, shapePaint)
        }

        val onRail = pet.mode == Pet.Mode.HANG
        val showHint = pet.mode == Pet.Mode.DRAG && pet.nearRail
        if (onRail || showHint) {
            val th = max(3f * density, Sprites.barThickness * k)
            shapePaint.color = if (onRail) railColor else accentColor
            rect.set(2f * density, ayw - th / 2f, winW - 2f * density, ayw + th / 2f)
            canvas.drawRoundRect(rect, th / 2f, th / 2f, shapePaint)
        }

        canvas.save()
        canvas.translate(axw, ayw)
        val rot = pet.rotation()
        if (rot != 0f) canvas.rotate(Math.toDegrees(rot.toDouble()).toFloat())
        canvas.scale(k * pet.drawSx, k * pet.drawSy)
        canvas.drawBitmap(s.bmp, -s.ax, -s.ay, spritePaint)
        canvas.restore()
    }

    private fun hit(x: Float, y: Float): Boolean {
        if (pet.mode == Pet.Mode.GONE) return false
        if (pet.mode == Pet.Mode.GROUND && (pet.st == "out" || pet.st == "pop")) return false
        val s = Sprites.map[pet.poseName()] ?: return false
        val k = pet.K
        val sx = max(0.05f, pet.drawSx)
        val sy = max(0.05f, pet.drawSy)
        val dx = x - anchorX()
        val dy = y - anchorY()
        val r = -pet.rotation()
        val cs = kotlin.math.cos(r)
        val sn = kotlin.math.sin(r)
        val lx = (dx * cs - dy * sn) / (k * sx) + s.ax
        val ly = (dx * sn + dy * cs) / (k * sy) + s.ay
        val pad = 14f * density / k
        return lx >= -pad && lx <= s.w + pad && ly >= -pad && ly <= s.h + pad
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val now = SystemClock.uptimeMillis()
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (!hit(e.x, e.y)) return false
                pet.pressDown(e.rawX, e.rawY, now)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                pet.pressMove(e.rawX, e.rawY, now)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                pet.pressUp(now)
                return true
            }
        }
        return true
    }
}
