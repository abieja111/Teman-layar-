package com.temanlayar.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONObject

/** Satu pose karakter. (ax, ay) adalah titik pegangan: kaki untuk pose di lantai, tangan untuk pose bergelantungan. */
class Sprite(val bmp: Bitmap, val w: Int, val h: Int, val ax: Float, val ay: Float)

object Sprites {
    var map: Map<String, Sprite> = emptyMap()
        private set
    var barThickness: Float = 9f
        private set

    fun load(ctx: Context) {
        if (map.isNotEmpty()) return
        val text = ctx.assets.open("sprites.json").bufferedReader().use { it.readText() }
        val root = JSONObject(text)
        barThickness = root.getDouble("barThickness").toFloat()
        val spr = root.getJSONObject("sprites")
        val out = HashMap<String, Sprite>()
        val keys = spr.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val o = spr.getJSONObject(k)
            val bmp = ctx.assets.open("sprites/$k.webp").use { BitmapFactory.decodeStream(it) } ?: continue
            out[k] = Sprite(
                bmp,
                o.getInt("w"),
                o.getInt("h"),
                o.getDouble("ax").toFloat(),
                o.getDouble("ay").toFloat()
            )
        }
        map = out
    }
}
