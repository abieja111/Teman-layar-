package com.temanlayar.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONObject
import kotlin.math.max

/** Satu pose karakter. (ax, ay) adalah titik pegangan: kaki untuk pose di lantai, tangan untuk pose bergelantungan. */
class Sprite(val bmp: Bitmap, val w: Int, val h: Int, val ax: Float, val ay: Float)

/**
 * Semua pose milik satu karakter.
 *
 * px         : pengali agar ukuran gambar karakter ini setara dengan karakter lain
 * alias      : pose yang tidak punya gambar sendiri memakai gambar pose lain
 * stand/greet/turnRight/turnLeft : nama pose untuk tiap keadaan
 * looks      : urutan pose saat karakter menoleh ke kiri dan kanan
 */
class SpriteSet(
    val id: String,
    private val sprites: Map<String, Sprite>,
    private val alias: Map<String, String>,
    val px: Float,
    val barThickness: Float,
    val stand: String,
    val greet: String,
    val turnRight: String,
    val turnLeft: String,
    val looks: List<List<Pair<String, Float>>>
) {
    fun get(name: String): Sprite? {
        val direct = sprites[name]
        if (direct != null) return direct
        val other = alias[name] ?: return null
        return sprites[other]
    }

    /** Pose yang benar-benar punya gambar sendiri. */
    fun entries(): Set<Map.Entry<String, Sprite>> = sprites.entries

    /** Setengah lebar karakter di lantai (dalam satuan yang sudah diseragamkan). */
    val halfW: Float by lazy {
        var half = 62f
        for ((name, s) in sprites) {
            if (name.startsWith("hang") || name.startsWith("swing")) continue
            half = max(half, max(s.ax, s.w - s.ax) * px)
        }
        half
    }
}

object Sprites {
    /** id karakter dan nama yang ditampilkan di aplikasi. */
    val characters: List<Pair<String, String>> = listOf(
        "haimiya" to "Haimiya",
        "tenka" to "Tenka"
    )

    private val cache = HashMap<String, SpriteSet>()

    fun has(id: String): Boolean = characters.any { it.first == id }

    fun get(ctx: Context, id: String): SpriteSet {
        val hit = cache[id]
        if (hit != null) return hit
        val dir = "chars/$id"
        val text = ctx.assets.open("$dir/sprites.json").bufferedReader().use { it.readText() }
        val root = JSONObject(text)

        val map = HashMap<String, Sprite>()
        val spr = root.getJSONObject("sprites")
        val keys = spr.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val o = spr.getJSONObject(k)
            val bmp = ctx.assets.open("$dir/sprites/$k.webp").use { BitmapFactory.decodeStream(it) } ?: continue
            map[k] = Sprite(bmp, o.getInt("w"), o.getInt("h"), o.getDouble("ax").toFloat(), o.getDouble("ay").toFloat())
        }

        val al = HashMap<String, String>()
        val ao = root.optJSONObject("alias")
        if (ao != null) {
            val ak = ao.keys()
            while (ak.hasNext()) {
                val k = ak.next()
                al[k] = ao.getString(k)
            }
        }

        val looks = ArrayList<List<Pair<String, Float>>>()
        val la = root.optJSONArray("looks")
        if (la != null) {
            for (i in 0 until la.length()) {
                val seqArr = la.getJSONArray(i)
                val seq = ArrayList<Pair<String, Float>>()
                for (j in 0 until seqArr.length()) {
                    val step = seqArr.getJSONArray(j)
                    seq.add(step.getString(0) to step.getDouble(1).toFloat())
                }
                looks.add(seq)
            }
        }

        val set = SpriteSet(
            id,
            map,
            al,
            root.optDouble("px", 1.0).toFloat(),
            root.optDouble("barThickness", 9.0).toFloat(),
            root.getString("stand"),
            root.getString("greet"),
            root.getString("turnRight"),
            root.getString("turnLeft"),
            looks
        )
        cache[id] = set
        return set
    }
}
