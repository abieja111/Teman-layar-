package com.temanlayar.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.BitmapFactory

class MainActivity : Activity() {
    private lateinit var infoText: TextView
    private lateinit var permButton: Button
    private lateinit var toggleButton: Button

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences(PetService.PREFS, MODE_PRIVATE)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.setPadding(dp(24), dp(36), dp(24), dp(28))
        root.setBackgroundColor(Color.parseColor("#EEF1F6"))

        // pratinjau karakter
        val preview = ImageView(this)
        try {
            val bmp = assets.open("sprites/idle6.webp").use { BitmapFactory.decodeStream(it) }
            preview.setImageBitmap(bmp)
        } catch (e: Exception) {
            // abaikan jika gambar tidak ditemukan
        }
        preview.adjustViewBounds = true
        root.addView(preview, LinearLayout.LayoutParams(dp(110), dp(190)))

        val title = TextView(this)
        title.text = "Teman Layar"
        title.textSize = 26f
        title.setTextColor(Color.parseColor("#232634"))
        title.setPadding(0, dp(12), 0, dp(6))
        root.addView(title)

        infoText = TextView(this)
        infoText.textSize = 15f
        infoText.gravity = Gravity.CENTER
        infoText.setTextColor(Color.parseColor("#566075"))
        root.addView(infoText, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        permButton = Button(this)
        permButton.text = "Izinkan tampil di atas aplikasi lain"
        permButton.setOnClickListener {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        val btnLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        btnLp.topMargin = dp(20)
        root.addView(permButton, btnLp)

        toggleButton = Button(this)
        toggleButton.setOnClickListener {
            if (PetService.running) {
                startService(Intent(this, PetService::class.java).setAction(PetService.ACTION_STOP))
            } else {
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                }
                startForegroundService(Intent(this, PetService::class.java))
            }
            toggleButton.postDelayed({ refresh() }, 400)
        }
        val toggleLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        toggleLp.topMargin = dp(8)
        root.addView(toggleButton, toggleLp)

        val sizeLabel = TextView(this)
        sizeLabel.text = "Ukuran karakter"
        sizeLabel.textSize = 14f
        sizeLabel.setTextColor(Color.parseColor("#566075"))
        sizeLabel.setPadding(0, dp(24), 0, dp(4))
        root.addView(sizeLabel)

        val group = RadioGroup(this)
        group.orientation = RadioGroup.HORIZONTAL
        val options = listOf("s" to "Kecil", "m" to "Sedang", "l" to "Besar")
        val current = prefs.getString(PetService.PREF_SIZE, "m") ?: "m"
        for ((key, label) in options) {
            val rb = RadioButton(this)
            rb.text = label
            rb.id = View.generateViewId()
            rb.tag = key
            rb.isChecked = key == current
            group.addView(rb)
        }
        group.setOnCheckedChangeListener { g, checkedId ->
            val key = g.findViewById<RadioButton>(checkedId)?.tag as? String ?: return@setOnCheckedChangeListener
            prefs.edit().putString(PetService.PREF_SIZE, key).apply()
            if (PetService.running) {
                startService(
                    Intent(this, PetService::class.java)
                        .setAction(PetService.ACTION_SIZE)
                        .putExtra(PetService.EXTRA_SIZE, key)
                )
            }
        }
        root.addView(group)

        val tips = TextView(this)
        tips.text = "Sentuh dan seret karakternya ke atas, lepas dekat batang untuk bergelantung. " +
            "Biarkan di bawah, dia berjalan sendiri. Hentikan kapan saja dari tombol di sini atau dari notifikasi."
        tips.textSize = 13f
        tips.gravity = Gravity.CENTER
        tips.setTextColor(Color.parseColor("#566075"))
        tips.setPadding(0, dp(28), 0, 0)
        root.addView(tips)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.parseColor("#EEF1F6"))
        scroll.addView(root)
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val canDraw = Settings.canDrawOverlays(this)
        val on = PetService.running
        permButton.visibility = if (canDraw) View.GONE else View.VISIBLE
        toggleButton.isEnabled = canDraw
        toggleButton.text = if (on) "Hentikan karakter" else "Munculkan karakter"
        infoText.text = when {
            !canDraw -> "Agar karakter bisa muncul di atas aplikasi lain, aktifkan izin tampil di atas aplikasi lain dulu."
            on -> "Karakter sedang aktif di layar Anda."
            else -> "Tekan tombol di bawah untuk memunculkan karakter di layar."
        }
    }
}
