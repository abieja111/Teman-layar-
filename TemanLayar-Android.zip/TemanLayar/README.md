# Teman Layar (Android)

Karakter chibi (Haimiya dan Tenka) yang melayang di atas semua aplikasi. Dia berjalan dan berlari sendiri di dasar layar.
Sentuh dan seret ke atas, lepas dekat batang, maka dia bergelantungan dan berayun.
Kalau dilepas di tengah layar, dia jatuh lalu mendarat dan berjalan lagi.

## Cara mendapatkan APK

### Cara 1: Android Studio (di komputer)
1. Pasang Android Studio (gratis).
2. Pilih File > Open, lalu pilih folder ini.
3. Tunggu sinkronisasi Gradle selesai.
4. Sambungkan HP (aktifkan Opsi Pengembang dan USB debugging), lalu tekan Run.
   Untuk file APK saja: Build > Build Bundle(s) / APK(s) > Build APK(s).

### Cara 2: GitHub Actions (tanpa memasang apa pun)
1. Buat akun GitHub dan repositori baru.
2. Unggah seluruh isi folder ini ke repositori, termasuk folder tersembunyi `.github`.
   (Di browser komputer, seret semua file dan folder ke halaman "Add file > Upload files".)
3. Buka tab Actions, jalankan "Build APK" (Run workflow) kalau belum jalan sendiri.
4. Setelah selesai, buka hasil build dan unduh `TemanLayar-APK` (isinya `app-debug.apk`).
5. Kirim APK ke HP, lalu buka. Izinkan "pasang aplikasi dari sumber ini" kalau diminta.

## Cara memakai
1. Buka Teman Layar, tekan "Izinkan tampil di atas aplikasi lain", aktifkan izinnya, lalu kembali.
2. Tekan "Munculkan karakter".
3. Pilih karakter di halaman utama: Haimiya, Tenka, atau dua-duanya sekaligus. Atur juga ukurannya (Kecil / Sedang / Besar).
4. Hentikan dari tombol di aplikasi atau dari notifikasi "Hentikan". Notifikasi "Pop up lagi" memunculkan ulang karakternya.

## Catatan
- Minimal Android 8.0 (API 26).
- Saat karakter bergelantungan atau dibawa, area di sekitarnya menangkap sentuhan. Di lantai area ini kecil.
- Tenka hanya punya gambar hadap kanan. Gambar hadap kiri dibuat dengan membalik gambar.
- Tenka tidak punya pose ayunan dan satu tangan, jadi saat berayun dia memakai pose bergelantungan biasa yang dimiringkan.
- Kunci tanda tangan APK sekarang tetap (`app/debug.keystore`), jadi versi baru bisa dipasang di atas versi lama.
  Khusus dari versi pertama (tanpa kunci tetap) ke versi ini, hapus dulu aplikasi lama.
- Aplikasi belum diuji di perangkat. Kode dibuat dari versi web yang sudah berjalan.

## Struktur
- `Pet.kt` perilaku karakter (jalan, lari, diseret, jatuh, bergelantungan)
- `PetView.kt` gambar karakter dan sentuhan
- `PetService.kt` jendela overlay dan notifikasi
- `MainActivity.kt` halaman pengaturan
- `Sprites.kt` pemuat gambar per karakter
- `assets/chars/<karakter>` potongan gambar dari sprite sheet dan pengaturan pose tiap karakter
